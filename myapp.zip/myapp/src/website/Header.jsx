import React from 'react';
import "./Style.css";


function Header() {
  return (
    <div className='header'>
         <a href="#home">Home</a>
        <a href="#home">About</a>
        <a href="#home">Products</a>
        <a href="#home">Contact</a>
    </div>
  )
}

export default Header