import React from 'react'

function SideBar() {
  return (
    <div className='sideBar'>
       Sidebar
    </div>
  )
}

export default SideBar