import React from 'react'

function Gallary() {
  return (
    <div className='gallary'>
         <img src="https://i.imgur.com/yXOvdOSs.jpg" alt="imgg" />
        <img src="https://i.imgur.com/yXOvdOSs.jpg" alt="imgg" />
    </div>
  )
}

export default Gallary