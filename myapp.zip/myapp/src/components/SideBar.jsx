import React from 'react';
import "../App.css";


function SideBar() {
  return (
    <div  className="sideBar">SideBar</div>
  )
}

export default SideBar